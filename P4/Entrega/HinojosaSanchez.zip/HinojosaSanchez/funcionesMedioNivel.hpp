#ifndef FUNCIONESMEDIONIVEL_H
#define FUNCIONESMEDIONIVEL_H

#include "cambio.hpp"
#include "mochila.hpp"
#include "funciones.hpp"
#include "material.hpp"
#include "materialUsado.hpp"
#include "moneda.hpp"

using namespace std;

void problemaCambio();
void problemaMochila();

#endif